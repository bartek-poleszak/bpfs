#include "idisk.h"

IDisk::~IDisk()
{

}


IDisk::IDisk()
{

}
