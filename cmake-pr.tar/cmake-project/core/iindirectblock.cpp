#include "iindirectblock.h"

IIndirectBlock::~IIndirectBlock()
{

}
