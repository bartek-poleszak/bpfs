#include "ifreeblockmanager.h"

IFreeBlockManager::~IFreeBlockManager()
{

}
