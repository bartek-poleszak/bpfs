#include "log.h"

Log::Log()
{
}

std::ostream &Log::stream = std::cout;
