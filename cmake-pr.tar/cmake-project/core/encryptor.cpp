#include "encryptor.h"



Encryptor::~Encryptor()
{

}
